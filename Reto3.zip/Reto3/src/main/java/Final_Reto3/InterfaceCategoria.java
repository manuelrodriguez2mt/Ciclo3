/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Final_Reto3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author 
 */
public interface InterfaceCategoria extends CrudRepository<Categoria,Integer>{
    
}
